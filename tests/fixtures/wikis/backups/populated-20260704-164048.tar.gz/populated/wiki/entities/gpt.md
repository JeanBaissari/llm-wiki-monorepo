---
title: GPT
type: entity
created: 2026-01-15
updated: 2026-06-20
sources: [populated-fixture]
tags: [nlp, transformer, openai]
confidence: high
---
# GPT
Generative Pre-trained Transformer.

Related: [[Transformer]], [[bert_paper|BERT]], [[NLP]], [[LLM]]
